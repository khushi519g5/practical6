# labwork 7: Music Box

This is the starter code for labwork 7: Music Box. Please [check out the spec for an explanation of the starter files.
